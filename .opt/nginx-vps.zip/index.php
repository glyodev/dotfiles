<?php
//Directorio
$dir = getcwd();
$directorio = opendir($dir);

$archivos = array();
$carpetas = array();

//Carpetas y Archivos a excluir
$excluir = array('.', '..', 'index.php', 'assets', 'nginx-gary.zip');

while ($f = readdir($directorio)) {
    if (is_dir("$dir/$f") && !in_array($f, $excluir)) {
        $carpetas[] = $f;
    } else if (!in_array($f, $excluir)){
        //No es una carpeta, por ende lo mandamos a archivos
        $archivos[] = $f;
    }
}
closedir($directorio);

sort($carpetas,SORT_NATURAL | SORT_FLAG_CASE);
sort($archivos,SORT_NATURAL | SORT_FLAG_CASE);
?>

<!DOCTYPE html>
<html lang="en" data-bs-theme="dark">
    <head>
        <link rel="shortcut icon" href="./assets/favicon.ico" type="image/x-icon">
        <title>Localhost</title>
        <link rel="stylesheet" href="./assets/css/bootstrap.min.css">
    </head>
    <body>
        <div class="shadow">
            <div class="navbar px-5 py-3 bg-ligth">
                <a href="/" class="text-decoration-none">
                    <h1><img src="./assets/favicon.ico" width="100"> localhost</h1>
                </a>
                <div>
                    <a href="/" class="ms-3">nginx</a>
                    <a href="/phpmyadmin/" class="ms-3">phpmyadmin</a>
                    <a href="/phppgadmin/" class="ms-3">phppgadmin</a>
                    <!-- <a href="/pgadmin4/" class="ms-3">pgadmin4</a> -->
                    <a href="/phpinfo.php" target="_blank" class="ms-3">phpinfo</a>
                </div>
	    </div>
	    <hr>
        </div>
        <br>
        <div class="container my-3">
            <h2 class="fw-bold">Directorios</h2>
            <div>
                <div class="col list-group">
		<?php
		if (count($carpetas) > 0) {
                    //Mostrar Carpetas
                    $i = 1;
                    foreach ($carpetas as $carpeta) {
                        echo '<a href="' . $carpeta . '" class="list-group-item list-group-item-light list-group-item-action">' . $carpeta . '</a>';
		    }
		} else {
		    echo "No hay carpetas.";
		}
                ?>
                </div>
                <!-- <br>
                <nav class="center" aria-label="Page navigation example">
                    <ul class="pagination">
                        <li class="page-item"><a class="page-link" href="#">Previous</a></li>
                        <li class="page-item"><a class="page-link" href="#">1</a></li>
                        <li class="page-item"><a class="page-link" href="#">2</a></li>
                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                        <li class="page-item"><a class="page-link" href="#">Next</a></li>
                    </ul>
                </nav> -->
            </div>
	    <br>
	    <hr>
            <h2 class="fw-bold">Archivos</h2>
            <div class="col list-group">
	    <?php
	    if (count($archivos) > 0) {
                //Mostrar Archivos
                $i = 1;
                foreach ($archivos as $archivo) {
                    echo '<a href="' . $archivo . '" class="list-group-item list-group-item-light list-group-item-action">' . $archivo . '</a>';
		}
	    } else {
	    	echo "No hay archivos.";
	    }
            ?>
            </div>
	</div>
	<footer class="shadow fixed-bottom text-center py-4">
		<hr>
        	<?php echo $_SERVER['SERVER_SOFTWARE']; ?>
    	</footer>
        <script src="./assets/js/bootstrap.min.js"></script>
    </body>
</html>
